from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from typing import Any


@dataclass(frozen=True)
class MarketContract:
    ticker: str
    event_ticker: str
    title: str
    subtitle: str
    yes_label: str
    no_label: str
    rules_primary: str
    rules_secondary: str
    open_time: str | None
    close_time: str | None
    expiration_time: str | None
    floor_strike: float | None
    cap_strike: float | None
    status: str
    raw: dict[str, Any] = field(default_factory=dict)

    @classmethod
    def from_api(cls, raw: dict[str, Any]) -> "MarketContract":
        return cls(
            ticker=str(raw.get("ticker", "")),
            event_ticker=str(raw.get("event_ticker", "")),
            title=str(raw.get("title", "")),
            subtitle=str(raw.get("subtitle", "")),
            yes_label=str(
                raw.get("yes_sub_title", raw.get("yes_subtitle", raw.get("yes_label", "YES")))
            ),
            no_label=str(
                raw.get("no_sub_title", raw.get("no_subtitle", raw.get("no_label", "NO")))
            ),
            rules_primary=str(raw.get("rules_primary", "")),
            rules_secondary=str(raw.get("rules_secondary", "")),
            open_time=raw.get("open_time"),
            close_time=raw.get("close_time") or raw.get("close_time"),
            expiration_time=raw.get("expiration_time") or raw.get("expected_expiration_time"),
            floor_strike=_number(raw.get("floor_strike")),
            cap_strike=_number(raw.get("cap_strike")),
            status=str(raw.get("status", "")),
            raw=raw,
        )


def _number(value: Any) -> float | None:
    try:
        return None if value is None or value == "" else float(value)
    except (TypeError, ValueError):
        return None


@dataclass(frozen=True)
class ValidationIssue:
    validator: str
    passed: bool
    severity: str
    evidence: tuple[str, ...]
    explanation: str


@dataclass(frozen=True)
class LLMReview:
    has_issue: bool
    category: str
    confidence: float
    evidence: tuple[str, ...]
    explanation: str
    requires_human_review: bool


@dataclass(frozen=True)
class ScanResult:
    ticker: str
    content_hash: str
    deterministic: tuple[ValidationIssue, ...]
    llm: LLMReview | None
    changed: bool
    scanned_at: datetime
