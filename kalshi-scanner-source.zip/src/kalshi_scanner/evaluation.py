from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class Evaluation:
    precision: float
    recall: float
    f1: float
    false_positives: int
    false_negatives: int
    confusion_matrix: dict[str, int]
    manual_review_reduction: float | None


def evaluate(
    predicted: list[bool],
    actual: list[bool],
    reviewed_candidates: int | None = None,
    baseline_candidates: int | None = None,
) -> Evaluation:
    if len(predicted) != len(actual):
        raise ValueError("predicted and actual must have the same length")
    if any(type(value) is not bool for value in [*predicted, *actual]):
        raise ValueError("predicted and actual labels must be JSON booleans")
    if (reviewed_candidates is None) != (baseline_candidates is None):
        raise ValueError("provide both reviewed_candidates and baseline_candidates")
    if baseline_candidates is not None:
        if baseline_candidates <= 0 or reviewed_candidates is None:
            raise ValueError("baseline_candidates must be positive")
        if not 0 <= reviewed_candidates <= baseline_candidates:
            raise ValueError("reviewed_candidates must be between zero and baseline")
    tp = sum(p and a for p, a in zip(predicted, actual, strict=True))
    fp = sum(p and not a for p, a in zip(predicted, actual, strict=True))
    fn = sum(not p and a for p, a in zip(predicted, actual, strict=True))
    precision = tp / (tp + fp) if tp + fp else 0.0
    recall = tp / (tp + fn) if tp + fn else 0.0
    f1 = 2 * precision * recall / (precision + recall) if precision + recall else 0.0
    reduction = None
    if baseline_candidates is not None and reviewed_candidates is not None:
        reduction = 1 - reviewed_candidates / baseline_candidates
    return Evaluation(
        precision,
        recall,
        f1,
        fp,
        fn,
        {
            "true_positive": tp,
            "false_positive": fp,
            "false_negative": fn,
            "true_negative": sum(not p and not a for p, a in zip(predicted, actual, strict=True)),
        },
        reduction,
    )
