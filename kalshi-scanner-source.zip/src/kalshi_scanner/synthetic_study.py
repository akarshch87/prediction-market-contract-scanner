"""Run the complete scanner against labeled fictional contracts, without network access."""

from __future__ import annotations

import argparse
import contextlib
import io
import json
import random
import sqlite3
import tempfile
from collections import Counter
from pathlib import Path
from typing import Any

from kalshi_scanner.cli import scan
from kalshi_scanner.evaluation import evaluate


def create_sample(seed: int, each: int) -> list[dict[str, Any]]:
    if not 1 <= each <= 10000:
        raise ValueError("each must be between 1 and 10000")
    rng = random.Random(seed)
    names = (
        "clean_normal",
        "clean_formatted_number",
        "clean_percentage",
        "clean_timezone",
        "clean_acronym",
        "missing_title",
        "bad_chronology",
        "unfilled_rule",
        "threshold_mismatch",
        "identical_conditions",
        "equivalent_conditions",
        "percentage_unit_mismatch",
    )
    sample = []
    for case in names:
        for index in range(each):
            n = rng.randrange(1000, 100000)
            m: dict[str, Any] = {
                "ticker": f"SYN-{case}-{index}",
                "event_ticker": "SYN",
                "title": f"Will station {n} record rain?",
                "rules_primary": "Rain is measured at the station.",
                "open_time": "2027-01-01T00:00:00Z",
                "close_time": "2027-01-31T00:00:00Z",
                "expiration_time": "2027-02-01T00:00:00Z",
                "status": "open",
            }
            issue = False
            if case == "clean_formatted_number":
                m.update(title=f"Will price exceed ${n:,}?", floor_strike=n)
            elif case == "clean_percentage":
                m.update(title="Will the rate exceed 1.5%?", floor_strike=0.015)
            elif case == "clean_timezone":
                m["rules_primary"] = "Expiration is 2027-01-31."
            elif case == "clean_acronym":
                m["title"] = f"Will TODO band win contest {n}?"
            elif case == "missing_title":
                issue = True
                m["title"] = ""
            elif case == "bad_chronology":
                issue = True
                m["close_time"] = "2026-12-31T00:00:00Z"
            elif case == "unfilled_rule":
                issue = True
                m["rules_primary"] = "The settlement source is {{source}}."
            elif case == "threshold_mismatch":
                issue = True
                m.update(title=f"Will price exceed ${n:,}?", floor_strike=n + 10)
            elif case == "identical_conditions":
                issue = True
                m["rules_primary"] = "Resolves Yes if rain occurs. Resolves No if rain occurs."
            elif case == "equivalent_conditions":
                issue = True
                m["rules_primary"] = "Resolves Yes if rain occurs. Resolves No if it rains."
            elif case == "percentage_unit_mismatch":
                issue = True
                m.update(title="Will the rate exceed 1.5%?", floor_strike=0.025)
            sample.append({"contract": m, "has_issue": issue, "case": case})
    rng.shuffle(sample)
    return sample


def run(seed: int, each: int) -> dict[str, Any]:
    sample = create_sample(seed, each)
    with tempfile.TemporaryDirectory() as folder:
        path = Path(folder)
        fixture, database = path / "input.json", path / "scan.sqlite"
        fixture.write_text(json.dumps([row["contract"] for row in sample]), encoding="utf-8")
        with contextlib.redirect_stdout(io.StringIO()):
            scan(argparse.Namespace(fixture=fixture, db=database, min_updated_ts=None))
        with contextlib.closing(sqlite3.connect(database)) as conn:
            flagged = {
                row[0]
                for row in conn.execute("SELECT ticker FROM review_queue WHERE status='OPEN'")
            }
        predicted = [row["contract"]["ticker"] in flagged for row in sample]
        actual = [row["has_issue"] for row in sample]
        metric = evaluate(predicted, actual, sum(predicted), len(sample))
        by_case: dict[str, Counter[str]] = {}
        for row, prediction in zip(sample, predicted, strict=True):
            counts = by_case.setdefault(row["case"], Counter())
            counts["cases"] += 1
            counts["flagged"] += int(prediction)
        return {
            "seed": seed,
            "per_case": each,
            "sample_size": len(sample),
            "data_source": "fictional generated contracts",
            **metric.__dict__,
            "by_case": {key: dict(value) for key, value in sorted(by_case.items())},
        }


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--seed", type=int, default=20261118)
    parser.add_argument("--each", type=int, default=100)
    args = parser.parse_args()
    print(json.dumps(run(args.seed, args.each), indent=2))
