from __future__ import annotations

import hashlib
import json
import sqlite3
from pathlib import Path

from kalshi_scanner.models import MarketContract, ScanResult

SCHEMA = """
CREATE TABLE IF NOT EXISTS markets (ticker TEXT PRIMARY KEY, content_hash TEXT NOT NULL, payload_json TEXT NOT NULL, first_seen TEXT NOT NULL, last_seen TEXT NOT NULL, last_changed TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS validation_results (id INTEGER PRIMARY KEY, ticker TEXT NOT NULL, validator TEXT NOT NULL, passed INTEGER NOT NULL, severity TEXT NOT NULL, evidence_json TEXT NOT NULL, explanation TEXT NOT NULL, created_at TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS llm_reviews (ticker TEXT PRIMARY KEY, payload_json TEXT NOT NULL, created_at TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS review_queue (ticker TEXT PRIMARY KEY, status TEXT NOT NULL, reason TEXT NOT NULL, created_at TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS watermarks (name TEXT PRIMARY KEY, value TEXT NOT NULL);
"""

# Quote and volume fields change frequently without changing contract terms.
# Keep every other field so new rule metadata still causes revalidation.
VALIDATION_VERSION = "2"
VOLATILE_FIELDS = frozenset(
    {
        "updated_time",
        "yes_bid",
        "yes_bid_dollars",
        "yes_bid_size",
        "yes_bid_size_fp",
        "yes_ask",
        "yes_ask_dollars",
        "yes_ask_size",
        "yes_ask_size_fp",
        "no_bid",
        "no_bid_dollars",
        "no_bid_size",
        "no_bid_size_fp",
        "no_ask",
        "no_ask_dollars",
        "no_ask_size",
        "no_ask_size_fp",
        "last_price",
        "last_price_dollars",
        "previous_price",
        "previous_price_dollars",
        "previous_yes_bid",
        "previous_yes_bid_dollars",
        "previous_yes_ask",
        "previous_yes_ask_dollars",
        "volume",
        "volume_fp",
        "volume_24h",
        "volume_24h_fp",
        "open_interest",
        "open_interest_fp",
        "liquidity",
        "liquidity_dollars",
    }
)


class StateDB:
    def __init__(self, path: Path) -> None:
        self.path = path
        path.parent.mkdir(parents=True, exist_ok=True)
        self.connection = sqlite3.connect(path)
        self.connection.executescript(SCHEMA)

    def content_hash(self, market: MarketContract) -> str:
        terms = {k: v for k, v in market.raw.items() if k not in VOLATILE_FIELDS}
        return hashlib.sha256(
            json.dumps(
                {"validation_version": VALIDATION_VERSION, "terms": terms},
                sort_keys=True,
                default=str,
            ).encode()
        ).hexdigest()

    def changed(self, market: MarketContract) -> bool:
        row = self.connection.execute(
            "SELECT content_hash FROM markets WHERE ticker = ?", (market.ticker,)
        ).fetchone()
        return row is None or row[0] != self.content_hash(market)

    def save(self, result: ScanResult, market: MarketContract | None = None) -> None:
        # A failed validation or queue write must not leave a partially saved scan.
        with self.connection:
            self._save(result, market)

    def _save(self, result: ScanResult, market: MarketContract | None = None) -> None:
        market_json = json.dumps(market.raw if market else {"ticker": result.ticker})
        self.connection.execute(
            """INSERT INTO markets(ticker,content_hash,payload_json,first_seen,last_seen,last_changed)
            VALUES(?,?,?,?,?,?) ON CONFLICT(ticker) DO UPDATE SET
            content_hash=excluded.content_hash,payload_json=excluded.payload_json,
            last_seen=excluded.last_seen,last_changed=excluded.last_changed""",
            (
                result.ticker,
                result.content_hash,
                market_json,
                result.scanned_at.isoformat(),
                result.scanned_at.isoformat(),
                result.scanned_at.isoformat(),
            ),
        )
        for issue in result.deterministic:
            self.connection.execute(
                "INSERT INTO validation_results(ticker,validator,passed,severity,evidence_json,explanation,created_at) VALUES(?,?,?,?,?,?,?)",
                (
                    result.ticker,
                    issue.validator,
                    int(issue.passed),
                    issue.severity,
                    json.dumps(issue.evidence),
                    issue.explanation,
                    result.scanned_at.isoformat(),
                ),
            )
        if result.llm:
            self.connection.execute(
                "INSERT OR REPLACE INTO llm_reviews(ticker,payload_json,created_at) VALUES(?,?,?)",
                (result.ticker, json.dumps(result.llm.__dict__), result.scanned_at.isoformat()),
            )
        reasons = [issue.explanation for issue in result.deterministic if not issue.passed]
        if result.llm and result.llm.requires_human_review:
            reasons.append(result.llm.explanation)
        if reasons:
            self.connection.execute(
                "INSERT INTO review_queue(ticker,status,reason,created_at) VALUES(?,?,?,?) "
                "ON CONFLICT(ticker) DO UPDATE SET status='OPEN',reason=excluded.reason",
                (result.ticker, "OPEN", " | ".join(reasons), result.scanned_at.isoformat()),
            )
        else:
            self.connection.execute(
                "UPDATE review_queue SET status='RESOLVED',reason=? WHERE ticker=?",
                ("No checks require review after latest changed-contract scan", result.ticker),
            )

    def mark_seen(self, ticker: str, seen_at: str, market: MarketContract | None = None) -> None:
        with self.connection:
            if market is None:
                self.connection.execute(
                    "UPDATE markets SET last_seen = ? WHERE ticker = ?", (seen_at, ticker)
                )
            else:
                self.connection.execute(
                    "UPDATE markets SET last_seen = ?, payload_json = ? WHERE ticker = ?",
                    (seen_at, json.dumps(market.raw), ticker),
                )

    def close(self) -> None:
        self.connection.close()
