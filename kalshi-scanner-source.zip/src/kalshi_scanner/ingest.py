from __future__ import annotations

import json
from collections.abc import Iterator
from typing import Any, cast
from urllib.parse import urlencode
from urllib.request import Request, urlopen

from kalshi_scanner.models import MarketContract


class KalshiClient:
    def __init__(
        self, base_url: str = "https://external-api.kalshi.com/trade-api/v2", timeout: float = 30
    ) -> None:
        self.base_url = base_url.rstrip("/")
        self.timeout = timeout

    def iter_markets(
        self, min_updated_ts: int | None = None, limit: int = 100
    ) -> Iterator[MarketContract]:
        cursor: str | None = None
        seen: set[str] = set()
        while True:
            params: dict[str, str | int] = {"limit": limit, "mve_filter": "exclude"}
            if cursor:
                if cursor in seen:
                    raise RuntimeError("Kalshi API returned a repeated pagination cursor")
                seen.add(cursor)
                params["cursor"] = cursor
            if min_updated_ts is not None:
                params["min_updated_ts"] = min_updated_ts
            data = self._get("/markets", params)
            for raw in data.get("markets", []):
                yield MarketContract.from_api(raw)
            cursor = data.get("cursor") or None
            if not cursor:
                break

    def _get(self, path: str, params: dict[str, str | int]) -> dict[str, Any]:
        request = Request(
            f"{self.base_url}{path}?{urlencode(params)}", headers={"Accept": "application/json"}
        )
        with urlopen(request, timeout=self.timeout) as response:
            if response.status >= 400:
                raise RuntimeError(f"Kalshi API returned HTTP {response.status}")
            return cast(dict[str, Any], json.loads(response.read().decode("utf-8")))
