from __future__ import annotations

import argparse
import json
from collections.abc import Iterable
from contextlib import closing
from datetime import datetime, timezone
from pathlib import Path

from kalshi_scanner.db import StateDB
from kalshi_scanner.evaluation import evaluate
from kalshi_scanner.ingest import KalshiClient
from kalshi_scanner.llm import NullProvider, review_with_retry
from kalshi_scanner.models import MarketContract, ScanResult
from kalshi_scanner.validators import validate_market


def parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        prog="kalshi-scan", description="Read-only Kalshi contract-integrity scanner"
    )
    sub = p.add_subparsers(dest="command", required=True)
    scan = sub.add_parser("scan", help="scan changed markets and write a human-review queue")
    scan.add_argument("--db", type=Path, default=Path("artifacts/kalshi.sqlite"))
    scan.add_argument("--min-updated-ts", type=int, default=None)
    scan.add_argument("--fixture", type=Path)
    ev = sub.add_parser("evaluate", help="evaluate manually labeled JSON arrays")
    ev.add_argument("--labels", type=Path, required=True)
    sample = sub.add_parser(
        "evaluate-contracts", help="derive predictions by scanning labeled contracts"
    )
    sample.add_argument("--sample", type=Path, required=True)
    return p


def scan(args: argparse.Namespace) -> int:
    markets: Iterable[MarketContract]
    if args.fixture:
        markets = [
            MarketContract.from_api(item)
            for item in json.loads(args.fixture.read_text(encoding="utf-8"))
        ]
    else:
        markets = KalshiClient().iter_markets(args.min_updated_ts)
    provider = NullProvider()
    flagged = 0
    changed_count = 0
    scanned_count = 0
    with closing(StateDB(args.db)) as db:
        for market in markets:
            scanned_count += 1
            changed = db.changed(market)
            if not changed:
                db.mark_seen(market.ticker, datetime.now(timezone.utc).isoformat())
                continue
            changed_count += 1
            issues = validate_market(market)
            llm = review_with_retry(provider, market)
            result = ScanResult(
                market.ticker,
                db.content_hash(market),
                issues,
                llm,
                changed,
                datetime.now(timezone.utc),
            )
            db.save(result, market)
            if any(not issue.passed for issue in issues):
                flagged += 1
            print(
                json.dumps(
                    {
                        "ticker": market.ticker,
                        "flagged": any(not issue.passed for issue in issues),
                        "issues": [issue.__dict__ for issue in issues],
                    },
                    default=str,
                )
            )
    print(
        json.dumps(
            {
                "contracts_scanned": scanned_count,
                "changed_scanned": changed_count,
                "deterministically_flagged": flagged,
            }
        )
    )
    return 0


def evaluate_labels(path: Path) -> int:
    data = json.loads(path.read_text(encoding="utf-8"))
    result = evaluate(
        data["predicted"],
        data["actual"],
        data.get("reviewed_candidates"),
        data.get("baseline_candidates"),
    )
    print(json.dumps(result.__dict__, indent=2))
    return 0


def main() -> None:
    args = parser().parse_args()
    if args.command == "scan":
        code = scan(args)
    elif args.command == "evaluate-contracts":
        code = evaluate_contracts(args.sample)
    else:
        code = evaluate_labels(args.labels)
    raise SystemExit(code)


def evaluate_contracts(path: Path) -> int:
    data = json.loads(path.read_text(encoding="utf-8"))
    rows = data["contracts"]
    predicted = [
        any(not item.passed for item in validate_market(MarketContract.from_api(row["contract"])))
        for row in rows
    ]
    actual = [row["has_issue"] for row in rows]
    result = evaluate(predicted, actual, sum(predicted), len(rows))
    print(
        json.dumps(
            {"sample_size": len(rows), "data_source": data["data_source"], **result.__dict__},
            indent=2,
        )
    )
    return 0


if __name__ == "__main__":
    main()
