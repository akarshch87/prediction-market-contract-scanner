"""Read-only Kalshi market-integrity triage pipeline."""

__version__ = "0.1.0"
