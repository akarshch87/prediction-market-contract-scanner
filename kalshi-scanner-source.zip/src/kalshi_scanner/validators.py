from __future__ import annotations

import re
from datetime import datetime

from kalshi_scanner.models import MarketContract, ValidationIssue


def _parse(value: str | None) -> datetime | None:
    if not value:
        return None
    try:
        parsed = datetime.fromisoformat(value.replace("Z", "+00:00"))
        return parsed if parsed.tzinfo is not None else None
    except ValueError:
        return None


def validate_market(market: MarketContract) -> tuple[ValidationIssue, ...]:
    checks = [
        _required(market),
        _chronology(market),
        _placeholder(market),
        _date_consistency(market),
        _threshold_consistency(market),
        _yes_no_contradiction(market),
    ]
    return tuple(checks)


def _required(m: MarketContract) -> ValidationIssue:
    missing = tuple(
        name
        for name, value in (
            ("ticker", m.ticker),
            ("title", m.title),
            ("rules_primary", m.rules_primary),
        )
        if not value.strip()
    )
    return ValidationIssue(
        "required_fields",
        not missing,
        "high" if missing else "info",
        missing,
        "Required identity and settlement fields are present."
        if not missing
        else "Missing required fields.",
    )


def _chronology(m: MarketContract) -> ValidationIssue:
    open_time, close_time, expiration = (
        _parse(m.open_time),
        _parse(m.close_time),
        _parse(m.expiration_time),
    )
    bad = (
        any(
            raw and parsed is None
            for raw, parsed in (
                (m.open_time, open_time),
                (m.close_time, close_time),
                (m.expiration_time, expiration),
            )
        )
        or open_time
        and close_time
        and open_time > close_time
        or close_time
        and expiration
        and close_time > expiration
    )
    evidence = (f"open={m.open_time}", f"close={m.close_time}", f"expiration={m.expiration_time}")
    return ValidationIssue(
        "chronology",
        not bad,
        "high" if bad else "info",
        evidence,
        "Dates are ordered."
        if not bad
        else "A lifecycle timestamp occurs after a later lifecycle timestamp.",
    )


def _placeholder(m: MarketContract) -> ValidationIssue:
    text = " ".join((m.title, m.subtitle, m.rules_primary, m.rules_secondary))
    found = tuple(re.findall(r"\bTODO\b|\bTBD\b|\{\{[^}]+\}\}|<string>|lorem ipsum", text))
    return ValidationIssue(
        "placeholder_text",
        not found,
        "medium" if found else "info",
        found,
        "No obvious placeholder text." if not found else "Placeholder-like text needs review.",
    )


def _date_consistency(m: MarketContract) -> ValidationIssue:
    text = " ".join((m.rules_primary, m.rules_secondary))
    dates_in_text = re.findall(
        r"\b(close|closes|closing|expiry|expiration|expires)\b\s*(?:date\s*)?(?:is|on|at|:)\s*(20\d{2}-\d{2}-\d{2})",
        text,
        re.IGNORECASE,
    )
    mismatches = []
    for kind, day in dates_in_text:
        structured = (
            m.close_time if kind.lower() in {"close", "closes", "closing"} else m.expiration_time
        )
        if structured and day != structured[:10]:
            mismatches.append(f"{kind}={day}; metadata={structured[:10]}")
    mismatch = bool(mismatches)
    return ValidationIssue(
        "date_text_consistency",
        not mismatch,
        "medium" if mismatch else "info",
        tuple(mismatches),
        "No title/rule date conflict detected."
        if not mismatch
        else "An explicit close/expiration date differs from its corresponding metadata.",
    )


def _threshold_consistency(m: MarketContract) -> ValidationIssue:
    text = " ".join((m.title, m.subtitle, m.rules_primary, m.rules_secondary))
    numbers = tuple(float(value) for value in re.findall(r"(?<![\w.])-?\d+(?:\.\d+)?", text))
    implied = tuple(value for value in (m.floor_strike, m.cap_strike) if value is not None)
    mismatch = bool(
        implied and numbers and not any(abs(a - b) < 1e-9 for a in implied for b in numbers)
    )
    return ValidationIssue(
        "threshold_consistency",
        not mismatch,
        "medium" if mismatch else "info",
        tuple(map(str, implied + numbers[:3])),
        "Threshold metadata is compatible with text."
        if not mismatch
        else "Numeric threshold metadata is not found in the text.",
    )


def _yes_no_contradiction(m: MarketContract) -> ValidationIssue:
    text = " ".join((m.rules_primary, m.rules_secondary)).lower()
    conditions: dict[str, set[str]] = {"yes": set(), "no": set()}
    for side, condition in re.findall(r"resolves?\s+(?:to\s+)?(yes|no)\s+if\s+([^.;]+)", text):
        conditions[side].add(" ".join(condition.split()))
    conflicts = conditions["yes"] & conditions["no"]
    contradiction = bool(conflicts)
    return ValidationIssue(
        "yes_no_labels",
        not contradiction,
        "high" if contradiction else "info",
        tuple(sorted(conflicts)),
        "No identical explicit YES/NO settlement conditions found."
        if not contradiction
        else "The same explicit condition resolves both YES and NO; human review required.",
    )
