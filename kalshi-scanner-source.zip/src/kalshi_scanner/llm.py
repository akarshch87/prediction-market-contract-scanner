from __future__ import annotations

import json
from typing import Any, Protocol

from kalshi_scanner.models import LLMReview, MarketContract


class SemanticProvider(Protocol):
    def review(self, market: MarketContract) -> dict[str, Any]: ...


class NullProvider:
    """Safe default: no network call and no automatic finding."""

    def review(self, market: MarketContract) -> dict[str, Any]:
        return {
            "has_issue": False,
            "category": "NO_REVIEW",
            "confidence": 0.0,
            "evidence": [],
            "explanation": "LLM review not configured.",
            "requires_human_review": False,
        }


def parse_review(payload: str | dict[str, Any], threshold: float = 0.8) -> LLMReview:
    data = json.loads(payload) if isinstance(payload, str) else payload
    confidence = float(data.get("confidence", 0))
    if not 0 <= confidence <= 1:
        raise ValueError("confidence must be in [0, 1]")
    evidence = data.get("evidence", [])
    if not isinstance(evidence, list) or not all(isinstance(item, str) for item in evidence):
        raise ValueError("evidence must be a list of strings")
    has_issue = bool(data.get("has_issue", False))
    return LLMReview(
        has_issue,
        str(data.get("category", "UNKNOWN")),
        confidence,
        tuple(evidence),
        str(data.get("explanation", "")),
        bool(data.get("requires_human_review", has_issue and confidence >= threshold)),
    )


def review_with_retry(
    provider: SemanticProvider, market: MarketContract, threshold: float = 0.8, attempts: int = 2
) -> LLMReview:
    last_error: Exception | None = None
    for _ in range(attempts):
        try:
            return parse_review(provider.review(market), threshold)
        except (ValueError, TypeError, json.JSONDecodeError) as exc:
            last_error = exc
    raise ValueError(f"LLM provider returned invalid structured output: {last_error}")
