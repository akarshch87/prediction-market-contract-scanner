# Validation

Run the offline checks with:

```powershell
python -m pip install -e ".[dev]"
pytest
ruff check .
ruff format --check .
mypy src
```

The tests exercise database rollback, change detection, pagination errors, missing fields, and review queue state. A seeded set of 500 generated contracts checks simple threshold comparisons. These synthetic cases check behavior and do not establish performance on real markets.

For a meaningful quality estimate, use a representative manually labeled sample and record how it was selected. The example fixtures only demonstrate the evaluation workflow.
