# Validation: November 10, 2026

Local verification passed: **16 tests**, Ruff lint, Ruff format check, and strict mypy source checks. Tests run offline and use synthetic fixtures; they do not verify historical scale, production quality, realized financial results, or a live deployment. The added tests exercise atomic rollback on a queue write failure, incremental processing, and last-seen updates without duplicate validation.

```powershell
python -m pip install -e ".[dev]"
pytest
ruff check .
ruff format --check .
mypy src
```

The fixture scan processed two contracts, revalidated two changed records, and queued one candidate. Repeating the same fixture against the same SQLite state reported zero changed records. The `evaluate-contracts` command scanned four invented labeled examples; it demonstrates reproducible evaluation, not a statistically valid performance estimate. The older `evaluate --labels` command is an arithmetic illustration using supplied predictions.

GitHub Actions configuration is included, with read-only repository permissions. Remote CI success requires a verified Actions run. Docker was not run in this review.
