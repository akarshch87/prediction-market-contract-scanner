# Validation

Run the offline checks with:

```powershell
python -m pip install -e ".[dev]"
pytest
ruff check .
ruff format --check .
mypy src
```

The tests exercise database rollback, change detection, pagination errors, missing fields, and review queue state. A seeded set of 500 generated contracts checks simple threshold comparisons. These synthetic cases check behavior and do not establish performance on real markets.

For a meaningful quality estimate, use a representative manually labeled sample and record how it was selected. The example fixtures only demonstrate the evaluation workflow.

## Fictional pipeline study

`python -m kalshi_scanner.synthetic_study --seed 20261118 --each 100` generates 100 variants in each of 12 labeled scenarios and runs the scanner through the SQLite review queue. The examples are derived from a small set of templates and the sample distribution is intentionally balanced by scenario, so the 1,200 rows are not an independent sample of real markets. The labels describe the constructed cases, not external adjudication.

The run produced 500 true positives, 100 false positives, 200 false negatives, and 400 true negatives. Precision was 83.3 percent, recall 71.4 percent, and F1 76.9 percent for this sample. The queue contained 600 of 1,200 records. A legitimate name containing `TODO` produced the false positives. Equivalent but differently worded YES and NO conditions and percentage unit mismatches produced the false negatives. The percentage cases are deliberately not compared because metadata units can be ambiguous. This experiment does not estimate live detection rates or prove any market issue.

On November 18, 2026 a single public REST request loaded one market through `KalshiClient` and ran all six checks. This confirms that one response could be parsed at that moment; it does not validate pagination, coverage, or any finding.
