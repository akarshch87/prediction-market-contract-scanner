# Configuration

Python 3.12+; no runtime third-party dependencies. Install with `python -m pip install -e ".[dev]"` for development tools. `kalshi-scan scan --fixture PATH --db PATH` runs fully offline. Without `--fixture`, the scanner calls the read-only public endpoint. `--min-updated-ts` accepts Unix seconds. The scanner does not read `.env` automatically and does not start a background service. SQLite artifacts stay local and are ignored by Git.

Cursor and incremental-filter details were checked against the [official markets documentation](https://docs.kalshi.com/api-reference/market/get-markets) on October 16, 2026. Watermark scheduling and overlap are operator responsibilities in this prototype. The default null semantic provider makes no network or paid-model calls. A custom provider requires deliberate code integration and tests.
