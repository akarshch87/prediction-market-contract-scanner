# Methodology

## Incremental state

The client follows Kalshi's cursor until the API returns an empty cursor. It records the raw content hash for each ticker, so unchanged contracts are skipped on later scans. A real deployment should persist a watermark with a small overlap window and periodically perform a full lifecycle scan. Cursor repetition is treated as an error rather than an infinite loop.

## Deterministic checks

Rules are intentionally explainable. A failing result is a candidate for review, not proof of an invalid contract. The scanner stores evidence with every result so a reviewer can reproduce why a contract was queued.

## Semantic review

The provider interface isolates model choice. Structured output is validated, confidence is bounded to `[0, 1]`, and invalid output is retried. The LLM can prioritize human review; it cannot change a market or send a report.

## Evaluation

Manually label a frozen sample before measuring. Compute precision, recall, F1, false positives, false negatives, and confusion matrix. Manual-review reduction is a workload metric defined as `1 - reviewed_candidates / baseline_candidates`; it must be reported alongside recall so queue reduction cannot hide missed issues.
