# Methodology

## Incremental state

The client follows Kalshi's cursor until the API returns an empty cursor. It fingerprints all received fields except an explicit list of quote, volume, and update timestamp fields. The latest full response is still retained. This avoids running contract checks on price updates while unknown fields remain eligible to trigger revalidation. Bump `VALIDATION_VERSION` in `src/kalshi_scanner/db.py` when validator rules or the semantic provider change so previously stored markets are scanned again. Existing hashes from the earlier schema are revalidated on the first subsequent scan. A deployment should persist a watermark with a small overlap window and periodically scan without the update filter for broader lifecycle coverage. Composite markets remain excluded. Cursor repetition is treated as an error rather than an infinite loop.

## Deterministic checks

Rules are intentionally explainable. A failing result is a candidate for review, not proof of an invalid contract. The scanner stores evidence with every result so a reviewer can reproduce why a contract was queued.

## Semantic review

The provider interface isolates model choice. Structured output is validated, confidence is bounded to `[0, 1]`, and invalid output is retried. The LLM can prioritize human review; it cannot change a market or send a report.

## Evaluation

Manually label a frozen sample before measuring. Compute precision, recall, F1, false positives, false negatives, and confusion matrix. Manual-review reduction is a workload metric defined as `1 - reviewed_candidates / baseline_candidates`; it must be reported alongside recall so queue reduction cannot hide missed issues.
