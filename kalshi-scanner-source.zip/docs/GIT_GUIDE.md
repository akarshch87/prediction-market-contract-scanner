# Git/GitHub guide

Git records local snapshots; GitHub hosts a remote copy and review surface. Use:

```powershell
git status
git diff
git add .
git commit -m "feat: add deterministic contract validators"
git log --oneline --graph
git switch -c experiment
git push -u origin main
git pull --ff-only
```

The working tree is the files on disk. Staging chooses what goes into the next commit. A branch isolates a change; a pull request asks for review before merge. Actions runs `.github/workflows/ci.yml` on push and pull request. `.gitignore` prevents databases, logs, virtual environments, and `.env` files from being committed. Use `.env.example` for names only and rotate a credential if it ever reaches Git history.
