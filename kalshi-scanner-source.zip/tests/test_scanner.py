from pathlib import Path

from kalshi_scanner.db import StateDB
from kalshi_scanner.evaluation import evaluate
from kalshi_scanner.llm import parse_review
from kalshi_scanner.models import MarketContract, ScanResult
from kalshi_scanner.validators import validate_market


def market(**overrides: object) -> MarketContract:
    data = {
        "ticker": "TEST-1",
        "event_ticker": "TEST",
        "title": "Will rain occur on 2026-09-21?",
        "subtitle": "",
        "yes_subtitle": "Yes",
        "no_subtitle": "No",
        "rules_primary": "Resolves yes if rain occurs on 2026-09-21.",
        "open_time": "2026-01-01T00:00:00Z",
        "close_time": "2026-09-20T00:00:00Z",
        "expiration_time": "2026-09-21T00:00:00Z",
        "status": "open",
    }
    data.update(overrides)
    return MarketContract.from_api(data)


def failed_names(contract: MarketContract) -> set[str]:
    return {issue.validator for issue in validate_market(contract) if not issue.passed}


def test_valid_contract() -> None:
    assert failed_names(market()) == set()


def test_date_mismatch_and_chronology() -> None:
    assert "date_text_consistency" in failed_names(
        market(rules_primary="Expiration is 2026-09-23.")
    )
    assert "chronology" in failed_names(market(close_time="2026-09-23T00:00:00Z"))


def test_threshold_and_placeholder() -> None:
    assert "threshold_consistency" in failed_names(
        market(title="Will value exceed 100?", floor_strike=200)
    )
    assert "placeholder_text" in failed_names(market(rules_primary="TODO"))


def test_yes_no_contradiction_and_missing() -> None:
    assert "yes_no_labels" in failed_names(
        market(rules_primary="Resolves Yes if rain occurs. Resolves No if rain occurs.")
    )
    assert "required_fields" in failed_names(market(title=""))


def test_llm_schema() -> None:
    review = parse_review(
        {
            "has_issue": True,
            "category": "DATE_CONTRADICTION",
            "confidence": 0.92,
            "evidence": ["title"],
            "explanation": "date differs",
            "requires_human_review": True,
        }
    )
    assert review.requires_human_review is True


def test_evaluation_metrics() -> None:
    result = evaluate(
        [True, True, False, False],
        [True, False, True, False],
        reviewed_candidates=2,
        baseline_candidates=4,
    )
    assert result.precision == 0.5
    assert result.recall == 0.5
    assert result.f1 == 0.5
    assert result.manual_review_reduction == 0.5


def test_sqlite_state_change(tmp_path: Path) -> None:
    db = StateDB(tmp_path / "state.sqlite")
    contract = market()
    result = ScanResult(
        contract.ticker,
        db.content_hash(contract),
        tuple(validate_market(contract)),
        None,
        True,
        __import__("datetime").datetime.now(__import__("datetime").timezone.utc),
    )
    db.save(result)
    assert db.changed(contract) is False
    db.close()


def test_expected_labels_event_dates_and_foreign_titles_do_not_flag() -> None:
    assert "yes_no_labels" not in failed_names(
        market(yes_subtitle="Same proposition", no_subtitle="Same proposition")
    )
    assert "date_text_consistency" not in failed_names(
        market(expiration_time="2026-09-23T00:00:00Z")
    )
    assert "placeholder_text" not in failed_names(market(title="Will Todo Lo Fue chart?"))


def test_cli_second_scan_reports_zero_changed(tmp_path: Path, capsys) -> None:
    import argparse
    import json

    from kalshi_scanner.cli import scan

    fixture = tmp_path / "contracts.json"
    fixture.write_text(json.dumps([market().raw]), encoding="utf-8")
    args = argparse.Namespace(fixture=fixture, db=tmp_path / "scan.sqlite")
    scan(args)
    capsys.readouterr()
    scan(args)
    summary = json.loads(capsys.readouterr().out.strip().splitlines()[-1])
    assert summary["contracts_scanned"] == 1
    assert summary["changed_scanned"] == 0


def test_deterministic_queue_and_first_seen_preserved(tmp_path: Path) -> None:
    from datetime import datetime, timedelta, timezone

    db = StateDB(tmp_path / "queue.sqlite")
    start = datetime(2026, 10, 16, tzinfo=timezone.utc)
    bad, good = market(title="TODO"), market()
    for contract, time in ((bad, start), (good, start + timedelta(days=1))):
        db.save(
            ScanResult(
                contract.ticker,
                db.content_hash(contract),
                validate_market(contract),
                None,
                True,
                time,
            ),
            contract,
        )
        status = db.connection.execute("SELECT status FROM review_queue").fetchone()[0]
        assert status == ("OPEN" if contract is bad else "RESOLVED")
    row = db.connection.execute("SELECT first_seen,payload_json FROM markets").fetchone()
    assert row[0] == start.isoformat()
    assert "rules_primary" in row[1]
    db.close()


def test_evaluation_does_not_invent_review_reduction() -> None:
    import pytest

    assert evaluate([True], [True]).manual_review_reduction is None
    with pytest.raises(ValueError):
        evaluate([True], [True], reviewed_candidates=5, baseline_candidates=4)
    with pytest.raises(ValueError):
        evaluate([True], [True], baseline_candidates=4)


def test_evaluation_derives_predictions_from_contracts(tmp_path: Path, capsys) -> None:
    import json

    from kalshi_scanner.cli import evaluate_contracts

    sample = tmp_path / "sample.json"
    sample.write_text(
        json.dumps(
            {
                "data_source": "synthetic test",
                "contracts": [
                    {"contract": market(title="TODO").raw, "has_issue": False},
                    {"contract": market().raw, "has_issue": False},
                ],
            }
        ),
        encoding="utf-8",
    )
    evaluate_contracts(sample)
    result = json.loads(capsys.readouterr().out)
    assert result["sample_size"] == 2
    assert result["false_positives"] == 1


def test_naive_or_malformed_time_is_candidate_not_crash() -> None:
    assert "chronology" in failed_names(market(open_time="2026-01-01T00:00:00"))
    assert "chronology" in failed_names(market(close_time="not a date"))


def test_failed_queue_write_rolls_back_entire_result(tmp_path: Path) -> None:
    import sqlite3
    from datetime import datetime, timezone

    import pytest

    db = StateDB(tmp_path / "atomic.sqlite")
    contract = market(title="TODO")
    db.connection.execute(
        "CREATE TRIGGER reject_queue BEFORE INSERT ON review_queue "
        "BEGIN SELECT RAISE(ABORT, 'queue unavailable'); END"
    )
    result = ScanResult(
        contract.ticker,
        db.content_hash(contract),
        validate_market(contract),
        None,
        True,
        datetime.now(timezone.utc),
    )
    with pytest.raises(sqlite3.IntegrityError):
        db.save(result, contract)
    assert db.connection.execute("SELECT count(*) FROM markets").fetchone()[0] == 0
    assert db.connection.execute("SELECT count(*) FROM validation_results").fetchone()[0] == 0
    db.connection.execute("DROP TRIGGER reject_queue")
    db.save(result, contract)
    assert db.connection.execute("SELECT status FROM review_queue").fetchone()[0] == "OPEN"
    db.close()


def test_live_scan_processes_before_requesting_next_market(
    tmp_path: Path, monkeypatch, capsys
) -> None:
    import argparse
    import json
    import sqlite3

    from kalshi_scanner.cli import scan

    db_path = tmp_path / "stream.sqlite"

    def markets(_self, _min_updated_ts):
        yield market()
        with sqlite3.connect(db_path) as conn:
            assert conn.execute("SELECT count(*) FROM markets").fetchone()[0] == 1
        yield market(ticker="TEST-2")

    monkeypatch.setattr("kalshi_scanner.cli.KalshiClient.iter_markets", markets)
    scan(argparse.Namespace(fixture=None, db=db_path, min_updated_ts=None))
    summary = json.loads(capsys.readouterr().out.strip().splitlines()[-1])
    assert summary["contracts_scanned"] == 2
    assert summary["changed_scanned"] == 2


def test_unchanged_scan_updates_last_seen_without_revalidation(tmp_path: Path, capsys) -> None:
    import argparse
    import json
    import sqlite3

    from kalshi_scanner.cli import scan

    fixture, db_path = tmp_path / "markets.json", tmp_path / "seen.sqlite"
    fixture.write_text(json.dumps([market().raw]), encoding="utf-8")
    args = argparse.Namespace(fixture=fixture, db=db_path)
    scan(args)
    with sqlite3.connect(db_path) as conn:
        conn.execute("UPDATE markets SET last_seen = 'old'")
        original_count = conn.execute("SELECT count(*) FROM validation_results").fetchone()[0]
    scan(args)
    capsys.readouterr()
    with sqlite3.connect(db_path) as conn:
        first, last, changed = conn.execute(
            "SELECT first_seen, last_seen, last_changed FROM markets"
        ).fetchone()
        assert last != "old"
        assert first == changed
        assert (
            conn.execute("SELECT count(*) FROM validation_results").fetchone()[0] == original_count
        )
